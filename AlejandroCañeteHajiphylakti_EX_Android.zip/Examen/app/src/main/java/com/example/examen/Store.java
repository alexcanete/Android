package com.example.examen;

import java.util.ArrayList;
import java.util.List;

public class Store {
    public static List<Tarea> lstTarea = new ArrayList<>();
    public static int TareaSelected;
}
